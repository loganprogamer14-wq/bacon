"""WASAPI loopback / microphone capture via PyAudioWPatch (Windows only).

Loopback is a passive tap on an output device: it does not open Discord's
devices exclusively and does not change what Discord plays or records.
Note: your own voice is not in the loopback stream (Discord only plays *other*
people), so you are never translating yourself unless you enable the mic.
"""
from __future__ import annotations

import queue
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class DeviceInfo:
    index: int
    name: str
    rate: int
    channels: int


def _pa():
    import pyaudiowpatch as pyaudio  # Windows-only dependency
    return pyaudio, pyaudio.PyAudio()


def list_loopback_devices() -> List[DeviceInfo]:
    pyaudio, p = _pa()
    try:
        return [DeviceInfo(d["index"], d["name"], int(d["defaultSampleRate"]), d["maxInputChannels"])
                for d in p.get_loopback_device_info_generator()]
    finally:
        p.terminate()


def list_mic_devices() -> List[DeviceInfo]:
    pyaudio, p = _pa()
    try:
        out = []
        wasapi = p.get_host_api_info_by_type(pyaudio.paWASAPI)["index"]
        for i in range(p.get_device_count()):
            d = p.get_device_info_by_index(i)
            if d["hostApi"] == wasapi and d["maxInputChannels"] > 0 and not d.get("isLoopbackDevice"):
                out.append(DeviceInfo(d["index"], d["name"], int(d["defaultSampleRate"]), d["maxInputChannels"]))
        return out
    finally:
        p.terminate()


def default_loopback() -> Optional[DeviceInfo]:
    pyaudio, p = _pa()
    try:
        d = p.get_default_wasapi_loopback()
        return DeviceInfo(d["index"], d["name"], int(d["defaultSampleRate"]), d["maxInputChannels"])
    except Exception:
        return None
    finally:
        p.terminate()


class Capture:
    """Pushes raw int16 PCM chunks (bytes) onto `self.q`. Never blocks the audio thread."""

    def __init__(self, device: DeviceInfo, label: str):
        self.device = device
        self.label = label
        self.q: "queue.Queue[bytes]" = queue.Queue(maxsize=200)  # ~6 s of 30 ms chunks
        self._pa = None
        self._stream = None
        self.dropped = 0

    def start(self) -> None:
        pyaudio, self._pa = _pa()
        d = self.device

        def cb(in_data, frame_count, time_info, status):
            try:
                self.q.put_nowait(in_data)
            except queue.Full:
                self.dropped += 1
            return (None, pyaudio.paContinue)

        self._stream = self._pa.open(
            format=pyaudio.paInt16, channels=d.channels, rate=d.rate, input=True,
            input_device_index=d.index, frames_per_buffer=int(d.rate * 0.03),
            stream_callback=cb)
        self._stream.start_stream()

    def stop(self) -> None:
        try:
            if self._stream is not None:
                self._stream.stop_stream()
                self._stream.close()
        finally:
            self._stream = None
            if self._pa is not None:
                self._pa.terminate()
                self._pa = None
