"""Stateful streaming mono conversion + resampling to 16 kHz float32."""
from __future__ import annotations

import numpy as np

TARGET_RATE = 16000


class StreamResampler:
    def __init__(self, in_rate: int, channels: int):
        self.in_rate = int(in_rate)
        self.channels = max(1, int(channels))
        self._soxr = None
        self._last = 0.0
        try:
            import soxr
            self._soxr = soxr.ResampleStream(self.in_rate, TARGET_RATE, 1, dtype="float32")
        except Exception:
            self._soxr = None  # fall back to linear interpolation

    def process(self, pcm16: bytes) -> np.ndarray:
        x = np.frombuffer(pcm16, dtype=np.int16)
        if self.channels > 1:
            x = x[: len(x) // self.channels * self.channels].reshape(-1, self.channels)
            mono = x.astype(np.float32).mean(axis=1)
        else:
            mono = x.astype(np.float32)
        mono /= 32768.0
        if self.in_rate == TARGET_RATE:
            return mono
        if self._soxr is not None:
            return self._soxr.resample_chunk(mono)
        n_out = int(len(mono) * TARGET_RATE / self.in_rate)
        if n_out == 0:
            return np.zeros(0, dtype=np.float32)
        t = np.linspace(0, len(mono) - 1, n_out)
        return np.interp(t, np.arange(len(mono)), mono).astype(np.float32)


def rms_level(x: np.ndarray) -> float:
    """0..1 meter value (roughly -60 dB .. 0 dB)."""
    if len(x) == 0:
        return 0.0
    rms = float(np.sqrt(np.mean(np.square(x))))
    if rms < 1e-6:
        return 0.0
    db = 20 * np.log10(rms)
    return float(min(1.0, max(0.0, (db + 60.0) / 60.0)))
