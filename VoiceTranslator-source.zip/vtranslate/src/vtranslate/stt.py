"""Local speech recognition with faster-whisper (audio never leaves the PC)."""
from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np


@dataclass
class Transcript:
    text: str
    lang: str
    lang_prob: float


def _bundled_model(size: str) -> Optional[str]:
    roots = [Path(getattr(sys, "_MEIPASS", "")), Path(sys.executable).parent, Path(__file__).resolve().parents[2]]
    for r in roots:
        cand = r / "models" / f"faster-whisper-{size}"
        if (cand / "model.bin").exists():
            return str(cand)
    return None


class Recognizer:
    def __init__(self, size: str = "small", device: str = "auto"):
        from faster_whisper import WhisperModel
        path = _bundled_model(size) or size   # falls back to a one-time download
        compute = "int8"
        dev = device
        if device in ("auto", "cuda"):
            try:
                import ctranslate2
                if ctranslate2.get_cuda_device_count() > 0:
                    dev, compute = "cuda", "float16"
                else:
                    dev = "cpu"
            except Exception:
                dev = "cpu"
        self.device = dev
        self.model = WhisperModel(path, device=dev, compute_type=compute, cpu_threads=4)

    def transcribe(self, audio: np.ndarray, language: Optional[str] = None,
                   fast: bool = False) -> Optional[Transcript]:
        if len(audio) < 16000 * 0.25:
            return None
        segs, info = self.model.transcribe(
            audio, language=language, beam_size=1 if fast else 4, best_of=1,
            temperature=0.0, vad_filter=False, condition_on_previous_text=False,
            no_speech_threshold=0.6, without_timestamps=True)
        parts = []
        for s in segs:
            if s.no_speech_prob > 0.7 or s.avg_logprob < -1.2:
                continue
            parts.append(s.text.strip())
        text = " ".join(p for p in parts if p).strip()
        if not text:
            return None
        return Transcript(text, info.language, float(info.language_probability))
