"""Voice activity detection: Silero (ONNX) if available, energy gate otherwise."""
from __future__ import annotations

import numpy as np


class EnergyVAD:
    """Crude fallback. Adaptive noise floor + threshold."""
    name = "energy"

    def __init__(self):
        self.floor = 1e-3

    def __call__(self, frame: np.ndarray) -> float:
        rms = float(np.sqrt(np.mean(np.square(frame)))) + 1e-9
        if rms < self.floor * 2:
            self.floor = 0.95 * self.floor + 0.05 * rms
        ratio = rms / (self.floor * 3.0)
        return float(min(1.0, ratio / 2.0))


class SileroVAD:
    """Wrapper over pysilero-vad. Handles both known API shapes."""
    name = "silero"

    def __init__(self):
        from pysilero_vad import SileroVoiceActivityDetector  # raises if missing
        self._vad = SileroVoiceActivityDetector()

    def __call__(self, frame: np.ndarray) -> float:
        pcm = (np.clip(frame, -1, 1) * 32767).astype(np.int16).tobytes()
        fn = getattr(self._vad, "process_chunk", None) or self._vad
        return float(fn(pcm))

    def reset(self):
        r = getattr(self._vad, "reset", None)
        if r:
            r()


def make_vad():
    """Each audio source needs its own instance (Silero is stateful)."""
    try:
        v = SileroVAD()
        v(np.zeros(512, dtype=np.float32))  # smoke test the API shape
        return v
    except Exception:
        return EnergyVAD()
