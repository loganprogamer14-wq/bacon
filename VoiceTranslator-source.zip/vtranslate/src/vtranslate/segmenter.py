"""Turns a stream of 32 ms audio frames + speech probabilities into utterances.

Pure logic (numpy only) so it can be unit-tested without audio hardware.
Emits ("partial", seg_id, audio) periodically while someone is talking and
("final", seg_id, audio) once they pause (or the segment gets too long).
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Callable, List, Optional, Tuple

import numpy as np

SAMPLE_RATE = 16000
FRAME = 512                      # samples per VAD frame (32 ms)
FRAME_MS = FRAME * 1000 // SAMPLE_RATE


@dataclass
class SegmenterConfig:
    start_prob: float = 0.5
    end_prob: float = 0.35               # hysteresis
    start_frames: int = 3                # ~96 ms of speech to open a segment
    end_silence_ms: int = 450
    min_speech_ms: int = 250
    max_segment_s: float = 10.0
    partial_interval_ms: int = 1000
    preroll_ms: int = 200
    tail_keep_ms: int = 150


Event = Tuple[str, int, np.ndarray]


class Segmenter:
    def __init__(self, vad: Callable[[np.ndarray], float],
                 cfg: Optional[SegmenterConfig] = None, source: str = ""):
        self.vad = vad
        self.cfg = cfg or SegmenterConfig()
        self.source = source
        self._pre = deque(maxlen=max(1, self.cfg.preroll_ms // FRAME_MS) + self.cfg.start_frames)
        self._buf = np.zeros(0, dtype=np.float32)   # leftover < FRAME
        self._seg: List[np.ndarray] = []
        self._active = False
        self._run = 0
        self._silence_ms = 0
        self._speech_ms = 0
        self._since_partial = 0
        self._next_id = 1
        self._cur_id = 0

    # -- public ---------------------------------------------------------
    def feed(self, samples: np.ndarray) -> List[Event]:
        """samples: float32 mono 16 kHz. Returns events produced."""
        events: List[Event] = []
        self._buf = np.concatenate([self._buf, samples.astype(np.float32, copy=False)])
        n = len(self._buf) // FRAME
        for i in range(n):
            frame = self._buf[i * FRAME:(i + 1) * FRAME]
            self._on_frame(frame, events)
        self._buf = self._buf[n * FRAME:]
        return events

    def reset(self) -> None:
        self._pre.clear()
        self._seg.clear()
        self._buf = np.zeros(0, dtype=np.float32)
        self._active = False
        self._run = self._silence_ms = self._speech_ms = self._since_partial = 0

    # -- internals ------------------------------------------------------
    def _on_frame(self, frame: np.ndarray, events: List[Event]) -> None:
        c = self.cfg
        p = float(self.vad(frame))
        if not self._active:
            self._pre.append(frame)
            if p >= c.start_prob:
                self._run += 1
                if self._run >= c.start_frames:
                    self._open()
            else:
                self._run = 0
            return

        self._seg.append(frame)
        if p >= c.end_prob:
            self._silence_ms = 0
            self._speech_ms += FRAME_MS
        else:
            self._silence_ms += FRAME_MS
        self._since_partial += FRAME_MS
        dur_ms = len(self._seg) * FRAME_MS

        if self._silence_ms >= c.end_silence_ms:
            self._close(events, forced=False)
        elif dur_ms >= c.max_segment_s * 1000:
            self._close(events, forced=True)
        elif self._since_partial >= c.partial_interval_ms and self._speech_ms >= c.min_speech_ms:
            self._since_partial = 0
            events.append(("partial", self._cur_id, np.concatenate(self._seg)))

    def _open(self) -> None:
        self._active = True
        self._cur_id = self._next_id
        self._next_id += 1
        self._seg = list(self._pre)
        self._pre.clear()
        self._run = 0
        self._silence_ms = 0
        self._speech_ms = len(self._seg) * FRAME_MS
        self._since_partial = 0

    def _close(self, events: List[Event], forced: bool) -> None:
        c = self.cfg
        if self._speech_ms >= c.min_speech_ms:
            seg = self._seg
            if not forced:
                drop = max(0, (self._silence_ms - c.tail_keep_ms) // FRAME_MS)
                if drop:
                    seg = seg[:-drop] if drop < len(seg) else seg
            events.append(("final", self._cur_id, np.concatenate(seg)))
        self._seg = []
        self._active = False
        self._run = 0
        self._speech_ms = 0
        self._silence_ms = 0
        if forced:
            # keep talking: immediately open a continuation segment
            self._open()
