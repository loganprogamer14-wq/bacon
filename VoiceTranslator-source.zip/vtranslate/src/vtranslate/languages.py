"""Language table. Codes are Whisper/ISO-639-1 codes."""

LANGUAGES = {
    "en": ("English", "🇬🇧"), "fr": ("French", "🇫🇷"), "de": ("German", "🇩🇪"),
    "es": ("Spanish", "🇪🇸"), "ru": ("Russian", "🇷🇺"), "ja": ("Japanese", "🇯🇵"),
    "ko": ("Korean", "🇰🇷"), "zh": ("Chinese", "🇨🇳"), "pt": ("Portuguese", "🇧🇷"),
    "it": ("Italian", "🇮🇹"), "nl": ("Dutch", "🇳🇱"), "pl": ("Polish", "🇵🇱"),
    "tr": ("Turkish", "🇹🇷"), "uk": ("Ukrainian", "🇺🇦"), "ar": ("Arabic", "🇸🇦"),
    "hi": ("Hindi", "🇮🇳"), "sv": ("Swedish", "🇸🇪"), "da": ("Danish", "🇩🇰"),
    "fi": ("Finnish", "🇫🇮"), "no": ("Norwegian", "🇳🇴"), "cs": ("Czech", "🇨🇿"),
    "el": ("Greek", "🇬🇷"), "he": ("Hebrew", "🇮🇱"), "id": ("Indonesian", "🇮🇩"),
    "vi": ("Vietnamese", "🇻🇳"), "th": ("Thai", "🇹🇭"), "ro": ("Romanian", "🇷🇴"),
    "hu": ("Hungarian", "🇭🇺"),
}


def name(code: str) -> str:
    return LANGUAGES.get(code, (code.upper(), ""))[0]


def flag(code: str) -> str:
    return LANGUAGES.get(code, ("", "🌐"))[1] or "🌐"
