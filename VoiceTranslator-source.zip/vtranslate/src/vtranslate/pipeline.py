"""Glue: capture -> resample -> VAD/segmenter -> Whisper -> dedup -> translate -> UI events.

Threads: one worker per audio source (cheap DSP + VAD), one STT worker (heavy),
a small pool for translation so network latency never blocks recognition.
"""
from __future__ import annotations

import queue
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Callable, List, Optional

from .audio.resample import StreamResampler, rms_level
from .config import Settings
from .dedup import Deduper, looks_like_hallucination
from .segmenter import Segmenter, SegmenterConfig
from .translate.backends import build_chain
from .translate.base import TranslateError
from .vad import make_vad


@dataclass
class SubtitleEvent:
    seg_id: str                 # unique across sources, e.g. "loop-12"
    source: str                 # "loop" | "mic"
    lang: str = ""
    original: str = ""
    translated: str = ""
    final: bool = False
    backend: str = ""
    error: str = ""


class Pipeline:
    def __init__(self, settings: Settings,
                 on_event: Callable[[SubtitleEvent], None],
                 on_level: Callable[[str, float], None],
                 on_status: Callable[[str], None]):
        self.s = settings
        self.on_event, self.on_level, self.on_status = on_event, on_level, on_status
        self._stop = threading.Event()
        self._threads: List[threading.Thread] = []
        self._captures = []
        self._jobs: "queue.Queue" = queue.Queue(maxsize=24)
        self._pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="translate")
        self._dedup = Deduper()
        self._chain = build_chain(settings.translator_order)
        self._history: List[str] = []
        self._rec = None
        self.privacy_line = ""

    # -- lifecycle ------------------------------------------------------
    def start(self, loopback, mic=None) -> None:
        """loopback/mic: audio.capture.DeviceInfo (mic may be None)."""
        from .audio.capture import Capture
        self._stop.clear()
        threading.Thread(target=self._boot, args=(loopback, mic), daemon=True).start()

    def _boot(self, loopback, mic) -> None:
        from .audio.capture import Capture
        try:
            self.on_status("Loading speech model (first run may download it)…")
            from .stt import Recognizer
            self._rec = Recognizer(self.s.whisper_model, self.s.compute_device)
            self.on_status(f"Speech model ready ({self._rec.device})")
            stt = threading.Thread(target=self._stt_loop, daemon=True, name="stt")
            stt.start()
            self._threads.append(stt)
            for dev, label in ((loopback, "loop"), (mic, "mic")):
                if dev is None:
                    continue
                cap = Capture(dev, label)
                cap.start()
                self._captures.append(cap)
                t = threading.Thread(target=self._source_loop, args=(cap,), daemon=True, name=f"src-{label}")
                t.start()
                self._threads.append(t)
            self.privacy_line = self._privacy()
            self.on_status("Listening — " + self.privacy_line)
        except Exception as e:  # noqa: BLE001
            self.on_status(f"Could not start: {e}")
            self.stop()

    def stop(self) -> None:
        self._stop.set()
        for c in self._captures:
            try:
                c.stop()
            except Exception:
                pass
        self._captures.clear()
        self._threads.clear()
        self.on_status("Stopped")

    def clear_data(self) -> None:
        self._dedup.clear()
        self._history.clear()
        while not self._jobs.empty():
            try:
                self._jobs.get_nowait()
            except queue.Empty:
                break

    def _privacy(self) -> str:
        online = self._chain.active_online()
        return ("speech recognized on this PC; transcribed TEXT (not audio) is sent to a translation service"
                if online else "everything is processed on this PC, nothing is sent online")

    # -- per-source worker ---------------------------------------------
    def _source_loop(self, cap) -> None:
        d = cap.device
        rs = StreamResampler(d.rate, d.channels)
        cfg = SegmenterConfig(end_silence_ms=self.s.end_silence_ms)
        seg = Segmenter(make_vad(), cfg, cap.label)
        last_level = 0.0
        while not self._stop.is_set():
            try:
                raw = cap.q.get(timeout=0.2)
            except queue.Empty:
                continue
            x = rs.process(raw)
            now = time.monotonic()
            if now - last_level > 0.05:
                self.on_level(cap.label, rms_level(x))
                last_level = now
            for kind, sid, audio in seg.feed(x):
                if kind == "partial" and not self.s.show_partials:
                    continue
                if kind == "partial" and self._jobs.qsize() > 4:
                    continue                       # shed load: partials are optional
                try:
                    self._jobs.put_nowait((kind, f"{cap.label}-{sid}", cap.label, audio))
                except queue.Full:
                    pass

    # -- STT worker -----------------------------------------------------
    def _stt_loop(self) -> None:
        lang = None if self.s.source_lang == "auto" else self.s.source_lang
        while not self._stop.is_set():
            try:
                kind, sid, source, audio = self._jobs.get(timeout=0.2)
            except queue.Empty:
                continue
            try:
                tr = self._rec.transcribe(audio, language=lang, fast=(kind == "partial"))
            except Exception as e:  # noqa: BLE001
                self.on_status(f"Recognition error: {e}")
                continue
            if tr is None or looks_like_hallucination(tr.text):
                continue
            if kind == "partial":
                self.on_event(SubtitleEvent(sid, source, tr.lang, tr.text, "", False))
                continue
            if self._dedup.is_duplicate(tr.text):
                self.on_event(SubtitleEvent(sid, source, tr.lang, "", "", True, error="dup"))
                continue
            # show the original immediately, translation follows
            self.on_event(SubtitleEvent(sid, source, tr.lang, tr.text, "", False))
            self._pool.submit(self._translate, sid, source, tr.lang, tr.text)

    def _translate(self, sid: str, source: str, lang: str, text: str) -> None:
        tgt = self.s.target_lang
        try:
            out, backend = self._chain.translate(text, lang, tgt, list(self._history))
            self._history = (self._history + [text])[-6:]
            self.privacy_line = self._privacy()
            self.on_event(SubtitleEvent(sid, source, lang, text, out, True, backend))
        except TranslateError as e:
            self.on_event(SubtitleEvent(sid, source, lang, text, "", True, error=str(e)))
