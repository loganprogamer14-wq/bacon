"""Suppress repeated sentences (Whisper loves to repeat itself on noise)."""
from __future__ import annotations

import re
import time
from collections import deque
from difflib import SequenceMatcher

_STRIP = re.compile(r"[\W_]+", re.UNICODE)

# Typical Whisper hallucinations on silence / music / noise (lower-case, normalised).
HALLUCINATIONS = {
    "thanks for watching", "thank you for watching", "thank you", "thanks", "bye", "you",
    "subtitles by the amaraorg community", "subscribe", "please subscribe",
    "merci davoir regarde cette video", "sous titres realises para la communaute damara org",
    "amara org", "продолжение следует", "субтитры сделал dimatorzok",
    "ご視聴ありがとうございました", "字幕由amara org社区提供",
}


def normalize(text: str) -> str:
    return _STRIP.sub(" ", text.lower()).strip()


def looks_like_hallucination(text: str) -> bool:
    n = normalize(text)
    if not n:
        return True
    if n in HALLUCINATIONS:
        return True
    words = n.split()
    # same word repeated 5+ times ("no no no no no")
    if len(words) >= 5 and len(set(words)) == 1:
        return True
    return False


class Deduper:
    def __init__(self, window_s: float = 8.0, similarity: float = 0.92, keep: int = 12):
        self.window_s = window_s
        self.similarity = similarity
        self._recent: deque = deque(maxlen=keep)

    def is_duplicate(self, text: str, now: float | None = None) -> bool:
        now = time.monotonic() if now is None else now
        n = normalize(text)
        if not n:
            return True
        for ts, prev in self._recent:
            if now - ts > self.window_s:
                continue
            if n == prev or SequenceMatcher(None, n, prev).ratio() >= self.similarity:
                return True
        self._recent.append((now, n))
        return False

    def clear(self) -> None:
        self._recent.clear()
