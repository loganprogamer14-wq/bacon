DARK_QSS = """
* { font-family: 'Segoe UI', sans-serif; font-size: 13px; color: #E6E8EC; }
QWidget { background: #14161A; }
QDialog, QWizard, QWizardPage { background: #14161A; }
QLabel#title { font-size: 18px; font-weight: 600; }
QLabel#status { color: #9AA3B2; padding: 4px 2px; }
QComboBox, QLineEdit, QSpinBox { background: #1E2127; border: 1px solid #2B303A; border-radius: 6px; padding: 6px 8px; }
QComboBox QAbstractItemView { background: #1E2127; selection-background-color: #2F6FED; }
QPushButton { background: #232831; border: 1px solid #2F3541; border-radius: 8px; padding: 8px 14px; }
QPushButton:hover { background: #2B313C; }
QPushButton#primary { background: #2F6FED; border: none; font-weight: 600; }
QPushButton#primary:hover { background: #4A83F2; }
QPushButton#stop { background: #D14B4B; border: none; font-weight: 600; }
QTextBrowser { background: #101216; border: 1px solid #23272F; border-radius: 10px; padding: 8px; font-size: 15px; }
QProgressBar { background: #1E2127; border: none; border-radius: 4px; height: 8px; text-align: center; }
QProgressBar::chunk { background: #3DDC84; border-radius: 4px; }
QCheckBox { spacing: 8px; }
QSlider::groove:horizontal { height: 4px; background: #2B303A; border-radius: 2px; }
QSlider::handle:horizontal { background: #2F6FED; width: 14px; margin: -6px 0; border-radius: 7px; }
"""
