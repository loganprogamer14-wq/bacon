from __future__ import annotations

from collections import OrderedDict

from PySide6 import QtCore, QtGui, QtWidgets as W

from .. import languages
from ..config import Settings


class Overlay(W.QWidget):
    """Frameless, always-on-top, click-through-optional subtitle bar.
    Drag with the left mouse button; resize with the grip bottom-right.
    Works over Discord and borderless-windowed games (not exclusive fullscreen)."""

    MAX_LINES = 3

    def __init__(self, settings: Settings):
        super().__init__(None, QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowStaysOnTopHint
                         | QtCore.Qt.Tool | QtCore.Qt.WindowDoesNotAcceptFocus)
        self.s = settings
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.setAttribute(QtCore.Qt.WA_ShowWithoutActivating)
        self._lines: "OrderedDict[str, dict]" = OrderedDict()
        self._drag = None
        self.label = W.QLabel(wordWrap=True, textFormat=QtCore.Qt.RichText)
        self.label.setStyleSheet("background: transparent;")
        lay = W.QVBoxLayout(self)
        lay.setContentsMargins(18, 12, 18, 12)
        lay.addWidget(self.label)
        grip = W.QSizeGrip(self)
        lay.addWidget(grip, 0, QtCore.Qt.AlignRight | QtCore.Qt.AlignBottom)
        self.resize(900, 140)
        self.move(300, 780)

    # -- data -----------------------------------------------------------
    def update_line(self, ev) -> None:
        if ev.error == "dup":
            self._lines.pop(ev.seg_id, None)
        else:
            self._lines[ev.seg_id] = dict(lang=ev.lang, orig=ev.original, tr=ev.translated, final=ev.final)
            while len(self._lines) > self.MAX_LINES:
                self._lines.popitem(last=False)
        self._render()

    def clear(self) -> None:
        self._lines.clear()
        self._render()

    def apply_settings(self) -> None:
        self._render()
        self.update()

    def _render(self) -> None:
        s = self.s
        fs = s.overlay_font_size
        html = []
        for d in self._lines.values():
            if not d["orig"] and not d["tr"]:
                continue
            tgt = d["tr"] or ("" if d["final"] else "…")
            if d["lang"] == s.target_lang and d["orig"]:
                html.append(f'<div style="font-size:{fs}px;color:{s.overlay_text_color}">{_e(d["orig"])}</div>')
                continue
            if s.show_original and d["orig"]:
                html.append(f'<div style="font-size:{int(fs*0.7)}px;color:{s.overlay_text_color};opacity:.7">'
                            f'{languages.flag(d["lang"])} {_e(d["orig"])}</div>')
            if tgt:
                html.append(f'<div style="font-size:{fs}px;color:{s.overlay_trans_color};font-weight:600">{_e(tgt)}</div>')
        self.label.setText("".join(html))

    # -- painting / dragging -------------------------------------------
    def paintEvent(self, _):
        p = QtGui.QPainter(self)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        p.setBrush(QtGui.QColor(10, 12, 16, int(255 * self.s.overlay_opacity / 100)))
        p.setPen(QtCore.Qt.NoPen)
        p.drawRoundedRect(self.rect(), 14, 14)

    def mousePressEvent(self, e):
        if e.button() == QtCore.Qt.LeftButton:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            self.move(e.globalPosition().toPoint() - self._drag)

    def mouseReleaseEvent(self, _):
        self._drag = None


def _e(t: str) -> str:
    return (t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
