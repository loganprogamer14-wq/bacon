from __future__ import annotations

from collections import OrderedDict

from PySide6 import QtCore, QtWidgets as W

from .. import languages
from ..config import Settings, data_dir
from ..pipeline import Pipeline, SubtitleEvent
from .overlay import Overlay
from .settings_dialog import SettingsDialog


class Bridge(QtCore.QObject):
    """Marshals worker-thread callbacks onto the Qt UI thread."""
    event = QtCore.Signal(object)
    level = QtCore.Signal(str, float)
    status = QtCore.Signal(str)


class MainWindow(W.QMainWindow):
    MAX_LINES = 80

    def __init__(self, settings: Settings):
        super().__init__()
        self.s = settings
        self.setWindowTitle("Voice Translator")
        self.resize(780, 640)
        self.pipe: Pipeline | None = None
        self.lines: "OrderedDict[str, dict]" = OrderedDict()
        self.overlay = Overlay(settings)
        self.bridge = Bridge()
        self.bridge.event.connect(self._on_event)
        self.bridge.level.connect(self._on_level)
        self.bridge.status.connect(self._on_status)

        root = W.QWidget(); self.setCentralWidget(root)
        v = W.QVBoxLayout(root)
        title = W.QLabel("Voice Translator"); title.setObjectName("title")
        v.addWidget(title)

        row = W.QHBoxLayout()
        self.lang = W.QComboBox()
        for code, (nm, fl) in languages.LANGUAGES.items():
            self.lang.addItem(f"{fl} {nm}", code)
        self.lang.setCurrentIndex(max(0, self.lang.findData(settings.target_lang)))
        self.lang.currentIndexChanged.connect(self._lang_changed)
        row.addWidget(W.QLabel("Translate into:")); row.addWidget(self.lang, 1)
        v.addLayout(row)

        self.loop = W.QComboBox(); self.mic = W.QComboBox()
        self.use_mic = W.QCheckBox("Also listen to my microphone"); self.use_mic.setChecked(settings.use_mic)
        v.addWidget(W.QLabel("Desktop audio to listen to (the output device Discord plays through):"))
        v.addWidget(self.loop)
        v.addWidget(self.use_mic); v.addWidget(self.mic)
        self._fill_devices()

        self.meter = W.QProgressBar(); self.meter.setRange(0, 100); self.meter.setTextVisible(False)
        v.addWidget(W.QLabel("Input level (if this never moves, pick another output device):"))
        v.addWidget(self.meter)

        self.view = W.QTextBrowser(); self.view.setOpenLinks(False)
        v.addWidget(self.view, 1)

        self.status = W.QLabel("Ready."); self.status.setObjectName("status"); self.status.setWordWrap(True)
        v.addWidget(self.status)

        btns = W.QHBoxLayout()
        self.btn = W.QPushButton("Start listening"); self.btn.setObjectName("primary")
        self.btn.clicked.connect(self.toggle)
        ov = W.QPushButton("Subtitle window"); ov.clicked.connect(self._toggle_overlay)
        st = W.QPushButton("Settings"); st.clicked.connect(self._settings)
        cl = W.QPushButton("Clear data"); cl.clicked.connect(self._clear)
        for b in (self.btn, ov, st, cl):
            btns.addWidget(b)
        v.addLayout(btns)
        if settings.overlay_visible:
            self.overlay.show()

    # -- devices --------------------------------------------------------
    def _fill_devices(self):
        self.loop.clear(); self.mic.clear()
        self._loop_devs, self._mic_devs = {}, {}
        try:
            from ..audio.capture import default_loopback, list_loopback_devices, list_mic_devices
            dl = default_loopback()
            self.loop.addItem("System default output" + (f" — {dl.name}" if dl else ""), "")
            for d in list_loopback_devices():
                self._loop_devs[d.name] = d
                self.loop.addItem(d.name, d.name)
            self.mic.addItem("(none)", "")
            for d in list_mic_devices():
                self._mic_devs[d.name] = d
                self.mic.addItem(d.name, d.name)
            self._default_loop = dl
            i = self.loop.findData(self.s.loopback_device)
            if i >= 0:
                self.loop.setCurrentIndex(i)
        except Exception as e:  # not on Windows / driver issue
            self.loop.addItem(f"Audio unavailable: {e}", "")
            self._default_loop = None

    # -- actions --------------------------------------------------------
    def toggle(self):
        if self.pipe is None:
            self.start()
        else:
            self.stop()

    def start(self):
        key = self.loop.currentData()
        dev = self._loop_devs.get(key) if key else self._default_loop
        if dev is None:
            self._on_status("No desktop audio device found.")
            return
        mic = self._mic_devs.get(self.mic.currentData()) if self.use_mic.isChecked() else None
        self.s.loopback_device = key or ""
        self.s.use_mic = self.use_mic.isChecked()
        self.s.save()
        self.pipe = Pipeline(self.s, self.bridge.event.emit, self.bridge.level.emit, self.bridge.status.emit)
        self.pipe.start(dev, mic)
        self.btn.setText("Stop listening"); self.btn.setObjectName("stop")
        self.btn.setStyleSheet(" ")  # re-polish
        self.loop.setEnabled(False)

    def stop(self):
        if self.pipe:
            self.pipe.stop()
            self.pipe = None
        self.btn.setText("Start listening"); self.btn.setObjectName("primary")
        self.btn.setStyleSheet(" ")
        self.loop.setEnabled(True)
        self.meter.setValue(0)

    def _lang_changed(self):
        self.s.target_lang = self.lang.currentData()
        self.s.save()
        self.overlay.apply_settings()

    def _toggle_overlay(self):
        self.overlay.setVisible(not self.overlay.isVisible())
        self.s.overlay_visible = self.overlay.isVisible()
        self.s.save()

    def _settings(self):
        dlg = SettingsDialog(self.s, self)
        if dlg.exec():
            dlg.apply()
            self.overlay.apply_settings()
            self._render()

    def _clear(self):
        self.lines.clear()
        self.view.clear()
        self.overlay.clear()
        if self.pipe:
            self.pipe.clear_data()
        self._on_status("Cleared transcript history and temporary data. (Audio is never stored.)")

    # -- pipeline callbacks (UI thread) --------------------------------
    def _on_event(self, ev: SubtitleEvent):
        self.overlay.update_line(ev)
        if ev.error == "dup":
            self.lines.pop(ev.seg_id, None)
        else:
            self.lines[ev.seg_id] = dict(lang=ev.lang, orig=ev.original, tr=ev.translated,
                                         final=ev.final, err=ev.error)
            while len(self.lines) > self.MAX_LINES:
                self.lines.popitem(last=False)
        self._render()

    def _on_level(self, source: str, lvl: float):
        if source == "loop":
            self.meter.setValue(int(lvl * 100))

    def _on_status(self, text: str):
        self.status.setText(("● " if self.pipe else "") + text)

    def _render(self):
        s = self.s
        out = []
        for d in self.lines.values():
            if not d["orig"] and not d["tr"]:
                continue
            same = d["lang"] == s.target_lang
            if s.show_original or same:
                out.append(f'<div style="color:#9AA3B2">{languages.flag(d["lang"])} '
                           f'<b>{languages.name(d["lang"])}:</b> {_e(d["orig"])}</div>')
            if not same:
                if d["tr"]:
                    out.append(f'<div>{languages.flag(s.target_lang)} <b>{languages.name(s.target_lang)}:</b> '
                               f'<span style="color:{s.overlay_trans_color}">{_e(d["tr"])}</span></div>')
                elif d["err"]:
                    out.append(f'<div style="color:#E8A33D">⚠ translation unavailable ({_e(d["err"])})</div>')
                elif not d["final"]:
                    out.append('<div style="color:#9AA3B2">…</div>')
            out.append("<div style='margin:4px'></div>")
        self.view.setHtml("".join(out))
        sb = self.view.verticalScrollBar(); sb.setValue(sb.maximum())

    def closeEvent(self, e):
        self.stop()
        self.overlay.close()
        super().closeEvent(e)


def _e(t: str) -> str:
    return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
