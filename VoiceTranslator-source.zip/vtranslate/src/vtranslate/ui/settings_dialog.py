from __future__ import annotations

from PySide6 import QtCore, QtGui, QtWidgets as W

from ..config import Settings, get_secret, set_secret


class ColorButton(W.QPushButton):
    def __init__(self, color: str):
        super().__init__()
        self.color = color
        self._paint()
        self.clicked.connect(self._pick)

    def _paint(self):
        self.setText(self.color)
        self.setStyleSheet(f"background:{self.color}; color:#000; border-radius:6px; padding:6px;")

    def _pick(self):
        c = W.QColorDialog.getColor(QtGui.QColor(self.color), self)
        if c.isValid():
            self.color = c.name()
            self._paint()


class SettingsDialog(W.QDialog):
    def __init__(self, s: Settings, parent=None):
        super().__init__(parent)
        self.s = s
        self.setWindowTitle("Settings")
        self.setMinimumWidth(460)
        form = W.QFormLayout(self)

        self.size = W.QSlider(QtCore.Qt.Horizontal); self.size.setRange(12, 60); self.size.setValue(s.overlay_font_size)
        self.opacity = W.QSlider(QtCore.Qt.Horizontal); self.opacity.setRange(0, 100); self.opacity.setValue(s.overlay_opacity)
        self.c_text = ColorButton(s.overlay_text_color)
        self.c_tr = ColorButton(s.overlay_trans_color)
        self.show_orig = W.QCheckBox("Show original language text"); self.show_orig.setChecked(s.show_original)
        self.partials = W.QCheckBox("Show live partial results while people speak"); self.partials.setChecked(s.show_partials)
        self.model = W.QComboBox(); self.model.addItems(["tiny", "base", "small", "medium", "large-v3"])
        self.model.setCurrentText(s.whisper_model)
        self.device = W.QComboBox(); self.device.addItems(["auto", "cpu", "cuda"]); self.device.setCurrentText(s.compute_device)
        self.silence = W.QSpinBox(); self.silence.setRange(200, 1500); self.silence.setSingleStep(50)
        self.silence.setSuffix(" ms"); self.silence.setValue(s.end_silence_ms)
        self.deepl = W.QLineEdit(get_secret("deepl")); self.deepl.setEchoMode(W.QLineEdit.Password)
        self.anth = W.QLineEdit(get_secret("anthropic")); self.anth.setEchoMode(W.QLineEdit.Password)
        self.order = W.QComboBox()
        self.order.addItems(["deepl,llm,offline", "llm,deepl,offline", "offline"])
        self.order.setCurrentText(s.translator_order if s.translator_order in
                                  [self.order.itemText(i) for i in range(self.order.count())] else "deepl,llm,offline")

        form.addRow("Subtitle text size", self.size)
        form.addRow("Background opacity", self.opacity)
        form.addRow("Original text color", self.c_text)
        form.addRow("Translation color", self.c_tr)
        form.addRow(self.show_orig)
        form.addRow(self.partials)
        form.addRow("Speech model (bigger = more accurate, slower)", self.model)
        form.addRow("Processing device", self.device)
        form.addRow("Pause length that ends a sentence", self.silence)
        form.addRow("DeepL API key (optional)", self.deepl)
        form.addRow("Anthropic API key (optional)", self.anth)
        form.addRow("Translation order", self.order)
        note = W.QLabel("Keys are stored in Windows Credential Manager, never in a file.\n"
                        "Model/device changes apply the next time you press Start.")
        note.setStyleSheet("color:#9AA3B2")
        form.addRow(note)
        bb = W.QDialogButtonBox(W.QDialogButtonBox.Ok | W.QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        form.addRow(bb)

    def apply(self) -> None:
        s = self.s
        s.overlay_font_size = self.size.value()
        s.overlay_opacity = self.opacity.value()
        s.overlay_text_color = self.c_text.color
        s.overlay_trans_color = self.c_tr.color
        s.show_original = self.show_orig.isChecked()
        s.show_partials = self.partials.isChecked()
        s.whisper_model = self.model.currentText()
        s.compute_device = self.device.currentText()
        s.end_silence_ms = self.silence.value()
        s.translator_order = self.order.currentText()
        set_secret("deepl", self.deepl.text().strip())
        set_secret("anthropic", self.anth.text().strip())
        s.save()
