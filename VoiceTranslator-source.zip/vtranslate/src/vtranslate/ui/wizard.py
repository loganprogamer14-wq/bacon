from __future__ import annotations

from PySide6 import QtWidgets as W

from .. import languages
from ..config import Settings, set_secret


class SetupWizard(W.QWizard):
    def __init__(self, s: Settings, parent=None):
        super().__init__(parent)
        self.s = s
        self.setWindowTitle("Voice Translator — first-time setup")
        self.setWizardStyle(W.QWizard.ModernStyle)

        p1 = W.QWizardPage(); p1.setTitle("Welcome")
        l = W.QVBoxLayout(p1)
        t = W.QLabel(
            "<b>Voice Translator</b> listens to what your PC plays (e.g. Discord voices) and shows live "
            "subtitles plus a translation.<br><br>"
            "<b>Privacy</b><ul>"
            "<li>Speech recognition runs <b>on this PC</b>. Audio is never uploaded.</li>"
            "<li>Nothing is recorded or saved.</li>"
            "<li>Only the transcribed <b>text</b> is sent to a translation service, and only if you add an API key. "
            "Without a key, offline translation is used and nothing leaves your PC.</li>"
            "<li>The window always shows whether audio is being processed.</li></ul>")
        t.setWordWrap(True); l.addWidget(t)

        p2 = W.QWizardPage(); p2.setTitle("Your language")
        f = W.QFormLayout(p2)
        self.lang = W.QComboBox()
        for code, (nm, fl) in languages.LANGUAGES.items():
            self.lang.addItem(f"{fl} {nm}", code)
        self.lang.setCurrentIndex(max(0, self.lang.findData(s.target_lang)))
        f.addRow("Translate everything into:", self.lang)
        f.addRow(W.QLabel("Audio devices: pick your headphones/speakers (the device Discord plays to) "
                          "in the main window. Your own voice is not included unless you turn on the microphone."))

        p3 = W.QWizardPage(); p3.setTitle("Better translations (optional)")
        f3 = W.QFormLayout(p3)
        self.deepl = W.QLineEdit(); self.deepl.setEchoMode(W.QLineEdit.Password)
        self.anth = W.QLineEdit(); self.anth.setEchoMode(W.QLineEdit.Password)
        f3.addRow("DeepL API key:", self.deepl)
        f3.addRow("Anthropic API key:", self.anth)
        f3.addRow(W.QLabel("Leave both empty to use free offline translation (lower quality). "
                           "You can change this later in Settings."))
        for p in (p1, p2, p3):
            self.addPage(p)

    def accept(self):
        self.s.target_lang = self.lang.currentData()
        if self.deepl.text().strip():
            set_secret("deepl", self.deepl.text().strip())
        if self.anth.text().strip():
            set_secret("anthropic", self.anth.text().strip())
        self.s.first_run_done = True
        self.s.save()
        super().accept()
