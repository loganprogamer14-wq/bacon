from __future__ import annotations

import sys


def main() -> None:
    from PySide6 import QtWidgets as W
    from .config import Settings
    from .ui.main_window import MainWindow
    from .ui.theme import DARK_QSS
    from .ui.wizard import SetupWizard

    app = W.QApplication(sys.argv)
    app.setApplicationName("Voice Translator")
    app.setStyleSheet(DARK_QSS)
    settings = Settings.load()
    if not settings.first_run_done:
        SetupWizard(settings).exec()
    win = MainWindow(settings)
    win.show()
    sys.exit(app.exec())
