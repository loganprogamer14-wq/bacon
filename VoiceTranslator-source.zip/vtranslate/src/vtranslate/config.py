"""Settings (JSON in %APPDATA%) and secrets (Windows Credential Manager via keyring).

API keys are never written to the JSON file.
"""
from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, fields
from pathlib import Path

APP_NAME = "VoiceTranslator"
KEYRING_SERVICE = "VoiceTranslator"


def data_dir() -> Path:
    base = os.environ.get("APPDATA") or str(Path.home() / ".config")
    p = Path(base) / APP_NAME
    p.mkdir(parents=True, exist_ok=True)
    return p


@dataclass
class Settings:
    target_lang: str = "en"
    source_lang: str = "auto"          # "auto" = detect per utterance
    loopback_device: str = ""          # "" = system default output
    mic_device: str = ""               # "" = off
    use_mic: bool = False
    show_original: bool = True
    whisper_model: str = "small"       # tiny/base/small/medium/large-v3
    compute_device: str = "auto"       # auto/cpu/cuda
    translator_order: str = "deepl,llm,offline"
    end_silence_ms: int = 450
    show_partials: bool = True
    # overlay look
    overlay_font_size: int = 22
    overlay_opacity: int = 70          # 0-100 background alpha
    overlay_text_color: str = "#FFFFFF"
    overlay_trans_color: str = "#7CF0A8"
    overlay_visible: bool = True
    first_run_done: bool = False

    @classmethod
    def load(cls) -> "Settings":
        path = data_dir() / "settings.json"
        s = cls()
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            known = {f.name for f in fields(cls)}
            for k, v in raw.items():
                if k in known:
                    setattr(s, k, v)
        except (OSError, ValueError):
            pass
        return s

    def save(self) -> None:
        (data_dir() / "settings.json").write_text(
            json.dumps(asdict(self), indent=2), encoding="utf-8")


def get_secret(name: str) -> str:
    try:
        import keyring
        return keyring.get_password(KEYRING_SERVICE, name) or ""
    except Exception:
        return os.environ.get(f"VT_{name.upper()}", "")


def set_secret(name: str, value: str) -> None:
    import keyring
    if value:
        keyring.set_password(KEYRING_SERVICE, name, value)
    else:
        try:
            keyring.delete_password(KEYRING_SERVICE, name)
        except Exception:
            pass
