from __future__ import annotations

from typing import List

from ..config import get_secret
from .base import Backend, Chain, TranslateError
from .. import languages

_DEEPL_TARGET = {"en": "EN-US", "pt": "PT-BR", "zh": "ZH-HANS", "no": "NB"}


class DeepL(Backend):
    name = "deepl"

    def available(self) -> bool:
        return bool(get_secret("deepl"))

    def translate(self, text, src, tgt, context):
        import requests
        key = get_secret("deepl")
        host = "api-free.deepl.com" if key.endswith(":fx") else "api.deepl.com"
        data = {"text": text, "target_lang": _DEEPL_TARGET.get(tgt, tgt.upper())}
        if src and src != "auto":
            data["source_lang"] = {"zh": "ZH", "no": "NB"}.get(src, src.upper())
        r = requests.post(f"https://{host}/v2/translate", data=data,
                          headers={"Authorization": f"DeepL-Auth-Key {key}"}, timeout=5)
        if r.status_code != 200:
            raise TranslateError(f"HTTP {r.status_code}")
        return r.json()["translations"][0]["text"]


class LLM(Backend):
    """Anthropic Messages API. Best at slang, context and fixing small ASR slips."""
    name = "llm"
    MODEL = "claude-haiku-4-5-20251001"

    def available(self) -> bool:
        return bool(get_secret("anthropic"))

    def translate(self, text, src, tgt, context):
        import requests
        ctx = "\n".join(context[-3:])
        system = (
            "You are a live subtitle translator for a voice chat. Translate the user's line into "
            f"{languages.name(tgt)}. Translate meaning, not words: keep slang, tone and register natural. "
            "The text comes from speech recognition, so silently fix obvious recognition errors when "
            "context makes the intended words clear. Output ONLY the translation, no notes or quotes.")
        user = (f"Previous lines (context only, do not translate):\n{ctx}\n\n" if ctx else "") + \
               f"Line to translate:\n{text}"
        r = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": get_secret("anthropic"), "anthropic-version": "2023-06-01",
                     "content-type": "application/json"},
            json={"model": self.MODEL, "max_tokens": 400, "system": system,
                  "messages": [{"role": "user", "content": user}]},
            timeout=8)
        if r.status_code != 200:
            raise TranslateError(f"HTTP {r.status_code}")
        return r.json()["content"][0]["text"]


class Offline(Backend):
    """Argos Translate (local). Language packs are downloaded once, then work offline."""
    name = "offline"
    sends_text_online = False

    def available(self) -> bool:
        try:
            import argostranslate.translate  # noqa: F401
            return True
        except Exception:
            return False

    @staticmethod
    def ensure_pair(src: str, tgt: str) -> None:
        """Download+install a language pack (needs internet once)."""
        import argostranslate.package as pkg
        pkg.update_package_index()
        for p in pkg.get_available_packages():
            if p.from_code == src and p.to_code == tgt:
                pkg.install_from_path(p.download())
                return
        raise TranslateError(f"no offline pack for {src}->{tgt}")

    def translate(self, text, src, tgt, context):
        import argostranslate.translate as tr
        if src == "auto":
            raise TranslateError("source language unknown")
        try:
            out = tr.translate(text, src, tgt)
        except Exception as e:
            raise TranslateError(str(e))
        if not out or out == text:
            # Argos returns input unchanged when a pack is missing. Try pivoting via English
            if src != "en" and tgt != "en":
                out = tr.translate(tr.translate(text, src, "en"), "en", tgt)
            if not out or out == text:
                raise TranslateError(f"offline pack {src}->{tgt} not installed")
        return out


def build_chain(order: str) -> Chain:
    table = {"deepl": DeepL, "llm": LLM, "offline": Offline}
    backends: List[Backend] = [table[n.strip()]() for n in order.split(",") if n.strip() in table]
    return Chain(backends)
