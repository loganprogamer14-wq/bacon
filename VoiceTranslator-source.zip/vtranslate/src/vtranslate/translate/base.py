from __future__ import annotations

import time
from typing import Dict, List, Optional, Tuple


class TranslateError(Exception):
    pass


class Backend:
    name = "base"
    sends_text_online = True

    def available(self) -> bool:
        return True

    def translate(self, text: str, src: str, tgt: str, context: List[str]) -> str:
        raise NotImplementedError


class Chain:
    """Tries backends in order. A failing backend is benched for `cooldown_s`
    so one dead connection doesn't add timeouts to every subtitle."""

    def __init__(self, backends: List[Backend], cooldown_s: float = 30.0, clock=time.monotonic):
        self.backends = backends
        self.cooldown_s = cooldown_s
        self._clock = clock
        self._benched: Dict[str, float] = {}
        self.last_error: str = ""

    def translate(self, text: str, src: str, tgt: str, context: Optional[List[str]] = None
                  ) -> Tuple[str, str]:
        if src == tgt:
            return text, "none"
        now = self._clock()
        errors = []
        for b in self.backends:
            if not b.available():
                continue
            if self._benched.get(b.name, 0) > now:
                continue
            try:
                out = b.translate(text, src, tgt, context or [])
                if out and out.strip():
                    self._benched.pop(b.name, None)
                    return out.strip(), b.name
                raise TranslateError("empty result")
            except Exception as e:  # noqa: BLE001 - any backend failure => next backend
                self._benched[b.name] = now + self.cooldown_s
                errors.append(f"{b.name}: {e}")
        self.last_error = "; ".join(errors) or "no translation backend available"
        raise TranslateError(self.last_error)

    def active_online(self) -> bool:
        """True if text is currently being sent to an external service."""
        now = self._clock()
        for b in self.backends:
            if b.available() and self._benched.get(b.name, 0) <= now:
                return b.sends_text_online
        return False
