; Inno Setup script. Compile with:  iscc packaging\installer.iss
#define AppName "Voice Translator"
#define AppVersion "1.0.0"

[Setup]
AppId={{6F1B2C7E-4D52-4C0E-9A55-3D0E7F7A1B11}
AppName={#AppName}
AppVersion={#AppVersion}
DefaultDirName={autopf}\VoiceTranslator
DefaultGroupName={#AppName}
OutputDir=..\dist-installer
OutputBaseFilename=VoiceTranslator-Setup-{#AppVersion}
Compression=lzma2
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest
WizardStyle=modern
UninstallDisplayName={#AppName}

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; Flags: unchecked

[Files]
Source: "..\dist\VoiceTranslator\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\VoiceTranslator.exe"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\VoiceTranslator.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\VoiceTranslator.exe"; Description: "Launch {#AppName}"; Flags: nowait postinstall skipifsilent
