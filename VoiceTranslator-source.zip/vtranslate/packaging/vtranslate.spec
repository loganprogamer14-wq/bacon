# PyInstaller spec — run from the repo root:  pyinstaller packaging/vtranslate.spec --noconfirm
import os
from PyInstaller.utils.hooks import collect_all

datas, binaries, hiddenimports = [], [], []
for pkg in ("faster_whisper", "ctranslate2", "onnxruntime", "pysilero_vad", "soxr",
            "pyaudiowpatch", "keyring", "argostranslate", "sentencepiece", "stanza"):
    try:
        d, b, h = collect_all(pkg)
        datas += d; binaries += b; hiddenimports += h
    except Exception:
        pass

hiddenimports += ["keyring.backends.Windows"]

# Pre-downloaded speech model (CI puts it in ./models/faster-whisper-small)
if os.path.isdir("models"):
    datas.append(("models", "models"))

a = Analysis(["run.py"], pathex=["src"], datas=datas, binaries=binaries,
             hiddenimports=hiddenimports, excludes=["tkinter", "matplotlib"])
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name="VoiceTranslator",
          console=False, icon=None)
coll = COLLECT(exe, a.binaries, a.datas, name="VoiceTranslator")
