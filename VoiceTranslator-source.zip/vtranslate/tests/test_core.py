import sys, os, tempfile, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
import numpy as np

from vtranslate.segmenter import Segmenter, SegmenterConfig, FRAME, SAMPLE_RATE
from vtranslate.dedup import Deduper, looks_like_hallucination
from vtranslate.translate.base import Backend, Chain, TranslateError
from vtranslate.audio.resample import StreamResampler, rms_level
from vtranslate.vad import EnergyVAD


def tone(sec, amp=0.3, f=220):
    t = np.arange(int(sec * SAMPLE_RATE)) / SAMPLE_RATE
    return (amp * np.sin(2 * np.pi * f * t)).astype(np.float32)


def silence(sec):
    return np.zeros(int(sec * SAMPLE_RATE), dtype=np.float32)


def amp_vad(frame):               # fake VAD: loud = speech
    return 0.9 if np.abs(frame).max() > 0.05 else 0.0


def run(seg, audio, chunk=480):
    ev = []
    for i in range(0, len(audio), chunk):
        ev += seg.feed(audio[i:i + chunk])
    return ev


class SegmenterTests(unittest.TestCase):
    def test_single_utterance(self):
        seg = Segmenter(amp_vad)
        ev = run(seg, np.concatenate([silence(1), tone(2), silence(1)]))
        finals = [e for e in ev if e[0] == "final"]
        self.assertEqual(len(finals), 1)
        dur = len(finals[0][2]) / SAMPLE_RATE
        self.assertTrue(1.9 < dur < 2.8, dur)

    def test_partials_emitted_during_long_speech(self):
        seg = Segmenter(amp_vad)
        ev = run(seg, np.concatenate([tone(3.5), silence(1)]))
        self.assertGreaterEqual(len([e for e in ev if e[0] == "partial"]), 2)
        self.assertEqual(len([e for e in ev if e[0] == "final"]), 1)

    def test_two_utterances_separate_ids(self):
        seg = Segmenter(amp_vad)
        ev = run(seg, np.concatenate([tone(1), silence(1), tone(1), silence(1)]))
        ids = [e[1] for e in ev if e[0] == "final"]
        self.assertEqual(len(ids), 2)
        self.assertNotEqual(ids[0], ids[1])

    def test_silence_produces_nothing(self):
        self.assertEqual(run(Segmenter(amp_vad), silence(5)), [])

    def test_blip_ignored(self):
        ev = run(Segmenter(amp_vad), np.concatenate([silence(1), tone(0.05), silence(1)]))
        self.assertEqual(ev, [])

    def test_max_length_forces_split(self):
        cfg = SegmenterConfig(max_segment_s=3.0)
        ev = run(Segmenter(amp_vad, cfg), np.concatenate([tone(7), silence(1)]))
        self.assertGreaterEqual(len([e for e in ev if e[0] == "final"]), 2)

    def test_energy_vad_detects_tone_over_noise(self):
        v = EnergyVAD()
        rng = np.random.default_rng(0)
        for _ in range(60):
            v((rng.standard_normal(FRAME) * 0.002).astype(np.float32))
        self.assertLess(v((rng.standard_normal(FRAME) * 0.002).astype(np.float32)), 0.5)
        self.assertGreater(v(tone(0.032)[:FRAME]), 0.5)


class DedupTests(unittest.TestCase):
    def test_exact_and_fuzzy(self):
        d = Deduper()
        self.assertFalse(d.is_duplicate("Salut, comment ça va ?", now=0))
        self.assertTrue(d.is_duplicate("salut comment ça va", now=1))
        self.assertTrue(d.is_duplicate("Salut, comment ca va?!", now=2))
        self.assertFalse(d.is_duplicate("Je vais bien merci", now=3))

    def test_window_expires(self):
        d = Deduper(window_s=5)
        self.assertFalse(d.is_duplicate("hello there", now=0))
        self.assertFalse(d.is_duplicate("hello there", now=10))

    def test_hallucinations(self):
        self.assertTrue(looks_like_hallucination("Thanks for watching!"))
        self.assertTrue(looks_like_hallucination("no no no no no no"))
        self.assertFalse(looks_like_hallucination("Thanks for the help, see you tomorrow"))


class Fake(Backend):
    def __init__(self, name, fail=False, online=True):
        self.name, self.fail, self.sends_text_online, self.calls = name, fail, online, 0

    def translate(self, text, src, tgt, context):
        self.calls += 1
        if self.fail:
            raise TranslateError("boom")
        return f"[{self.name}] {text}"


class ChainTests(unittest.TestCase):
    def test_fallback_and_cooldown(self):
        t = [0.0]
        a, b = Fake("a", fail=True), Fake("b", online=False)
        c = Chain([a, b], cooldown_s=30, clock=lambda: t[0])
        self.assertEqual(c.translate("hi", "fr", "en")[1], "b")
        c.translate("again", "fr", "en")
        self.assertEqual(a.calls, 1)           # benched, not retried
        self.assertFalse(c.active_online())
        t[0] = 31
        c.translate("later", "fr", "en")
        self.assertEqual(a.calls, 2)           # retried after cooldown

    def test_same_language_passthrough(self):
        c = Chain([Fake("a")])
        self.assertEqual(c.translate("hello", "en", "en"), ("hello", "none"))

    def test_all_fail_raises(self):
        with self.assertRaises(TranslateError):
            Chain([Fake("a", fail=True)]).translate("x", "fr", "en")


class ResampleTests(unittest.TestCase):
    def test_48k_stereo_to_16k_mono(self):
        rs = StreamResampler(48000, 2)
        n = 48000
        t = np.arange(n) / 48000
        mono = (0.5 * np.sin(2 * np.pi * 440 * t) * 32767).astype(np.int16)
        pcm = np.stack([mono, mono], 1).tobytes()
        out = np.concatenate([rs.process(pcm[i:i + 5760]) for i in range(0, len(pcm), 5760)])
        self.assertTrue(abs(len(out) - 16000) < 400, len(out))
        self.assertTrue(0.3 < np.abs(out).max() < 0.6)

    def test_level_meter(self):
        self.assertEqual(rms_level(np.zeros(100, dtype=np.float32)), 0.0)
        self.assertGreater(rms_level(tone(0.1)), 0.5)


class ConfigTests(unittest.TestCase):
    def test_roundtrip_has_no_secrets(self):
        with tempfile.TemporaryDirectory() as d:
            os.environ["APPDATA"] = d
            from vtranslate.config import Settings
            s = Settings(); s.target_lang = "fr"; s.save()
            self.assertEqual(Settings.load().target_lang, "fr")
            blob = open(os.path.join(d, "VoiceTranslator", "settings.json")).read()
            self.assertNotIn("key", blob.lower())


if __name__ == "__main__":
    unittest.main(verbosity=2)
