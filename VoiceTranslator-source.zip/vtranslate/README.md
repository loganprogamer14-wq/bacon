# Voice Translator

Live subtitles + translation for Discord voice calls (and anything else your PC plays).

* Captures **desktop audio** with WASAPI loopback (passive; doesn't touch Discord's devices).
* **Speech recognition runs locally** (faster-whisper + Silero VAD). Audio never leaves your PC.
* Only the transcribed **text** is sent to a translation service, and only if you add a key.
  No key → free offline translation (Argos), nothing leaves your PC.
* Floating always-on-top subtitle window with adjustable size, opacity and colors.

## Get the installer (no terminal on your PC)

1. Create a GitHub repo and upload this folder (or `git push` it).
2. Open the **Actions** tab → **Build Windows installer** → *Run workflow* (it also runs on every push to `main`).
3. When it finishes (~15–25 min), download **VoiceTranslator-Setup** from the run's *Artifacts* → unzip → run `VoiceTranslator-Setup-1.0.0.exe`.

The installer bundles the Whisper "small" model, so it works right after install.

## Use it

1. First launch: the setup wizard asks for your language and (optionally) API keys.
2. In the main window pick the **output device Discord plays through** (your headphones/speakers).
3. Press **Start listening**. The level bar should move when people talk. Subtitles appear in the
   window and in the floating bar (drag to move, grip at the bottom-right to resize).
4. Settings: text size, opacity, colors, hide original text, model size, translation order, API keys.

Tips
* Own voice isn't translated: Discord only plays *other* people to your speakers. Leave the mic option off.
* The floating bar works over Discord and **borderless/windowed** games. It cannot draw over *exclusive fullscreen*.
* Bigger model = more accurate but slower. `small` is a good CPU default; with an NVIDIA GPU use `medium` / `large-v3`
  (needs CUDA 12 + cuDNN 9 libraries installed; leave Device on `auto`).
* Offline translation needs a one-time language-pack download per language pair
  (`vtranslate.translate.backends.Offline.ensure_pair("fr", "en")`) — a button for this is on the to-do list.

## Run from source (Windows, Python 3.11)

    pip install -r requirements.txt
    python run.py
    python tests/test_core.py

## Privacy

* Nothing is recorded or saved. Subtitles live in memory; **Clear data** wipes them.
* Settings: `%APPDATA%\VoiceTranslator\settings.json` (no secrets). API keys: Windows Credential Manager.
* The status line states whether text is currently being sent to an online translator.
